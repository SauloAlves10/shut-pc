Shut PC! 1.2 Portable
--------------------------------------------------------------------------------------------
Shut PC! � uma poderosa ferramenta que permite agendar fun��es de desligar, reiniciar, logoff e hibernar para seu computador, al�m disso possui fun��es de agendamento de mensagens com alerta sonoro e inicializa��o com o Windows. Tudo � muito f�cil e r�pido com a utiliza��o da interface gr�fica da aplica��o, programando as tarefas a serem executadas em quest�es segundos.

Software criado e distribu�do por Saulo Alves. Este � um software gratuito, pode ser distribu�do e utilizado livremente. Nenhuma taxa pode ser cobrada por ele.

Pode ser que o antiv�rus exclua o execut�vel no momento da execu��o, adicione o execut�vel como exce��o para que a aplica��o possa funcionar.
